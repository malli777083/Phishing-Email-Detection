# Phishing Email Detection Model

Machine-learning project (Scikit-learn) that classifies an email as **Phishing** or **Safe**
using the email text and URL features.

## Features
- Trains on a CSV of phishing / legitimate emails (or built-in demo data)
- Feature extraction:
  - **Text:** TF-IDF (unigrams + bigrams) on the email body
  - **URL features:** number of links, links without HTTPS, raw IP address in link, URL shorteners, very long URLs, many hyphens in domain, `@` in URL
  - **Keyword / style features:** count of suspicious words (urgent, verify, suspended, password...), exclamation marks, uppercase ratio, text length
- Compares **Logistic Regression** and **Random Forest**, keeps the best
- Shows **accuracy, precision, recall, F1** and the **confusion matrix** (also saved as `confusion_matrix.png`)
- Classifies new emails and lists the **red flags** found

## Setup
    pip install scikit-learn pandas numpy matplotlib joblib

## Run
    python phishing_detector.py                              # demo data
    python phishing_detector.py --data Phishing_Email.csv    # real dataset
    python phishing_detector.py --predict "Your account is locked, verify at http://bit.ly/x1"
    python phishing_detector.py --interactive

## Dataset
Built-in demo data is **synthetic** (so the script runs out of the box); its near-100% accuracy
is not meaningful. For real results download a public dataset such as the Kaggle
"Phishing Email Dataset" (columns: `Email Text`, `Email Type`) and pass it with `--data`.
The script auto-detects common column names.

## Concepts learned
Text vectorisation (TF-IDF), feature engineering, train/test split, model comparison,
accuracy vs precision/recall, confusion matrix (false positives vs false negatives),
and common phishing indicators.

## Limitations
Content-based models can be fooled by well-written phishing mails. Real systems also use
sender reputation (SPF/DKIM/DMARC), link reputation lookups and user reporting.
